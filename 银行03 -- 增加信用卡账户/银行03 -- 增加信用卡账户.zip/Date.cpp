#include "Date.h"

Date::Date(int year, int month, int day):year(year), month(month), day(day)
{
	totalDays = 0;
}

int Date::distance(Date date) const
{
	int days_count = 0;
	int m[13] = { 0,31,28,31,30,31,30,31,31,30,31,30,31 };
	// ������ͬһ��
	if (date.year - year == 0)
	{
		// ���������
		if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
		{
			m[2] = 29;
		}
		// ���ڲ���ͬһ��
		for (int i = month; i < date.month; i++)
		{
			if (i == month)
			{
				days_count = m[i] - day;
				continue;
			}
			days_count += m[i];
		}
		days_count += date.day;
		// ������ͬһ��
		if (month == date.month)
		{
			return date.day - day;
		}
		return days_count;
	}
	else
	{
		for (int i = year; i < date.year; i++)
		{
			if (isLeapYear(i))
			{
				days_count += 366;
			}
			else
			{
				days_count += 365;
			}
		}
		if (isLeapYear(year))
		{
			m[2] = 29;
		}
		for (int i = 1; i < month; i++)
		{
			days_count -= m[i];
		}
		days_count -= day;
		if (isLeapYear(date.year))
		{
			m[2] = 29;
		}
		else
		{
			m[2] = 28;
		}
		for (int i = 1; i < date.month; i++)
		{
			days_count += m[i];
		}
		days_count += date.day;
		return days_count;
	}
}
