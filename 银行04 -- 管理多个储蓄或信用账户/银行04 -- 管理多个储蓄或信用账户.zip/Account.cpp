#include "Account.h"

double total = 0;

void Account::show()
{
	cout << id << "\tBalance: " << balance;
}